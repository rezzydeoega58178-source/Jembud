
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "200"))

DEVS = list(map(int, os.getenv("DEVS", "8172517676").split()))

API_ID = int(os.getenv("API_ID", "33415598"))

API_HASH = os.getenv("API_HASH", "2e7977511ec586f3e7ab2daeecd50e08")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8008800937:AAFw3J-fr0Kcf5Y4ZlV6Pl489eI6ShTI3rs")

OWNER_ID = int(os.getenv("OWNER_ID", "8172517676"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1004410571243").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://Ipanndongok:Ipanndongok@ipanndongok.bg7xf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", " -1004410571243"))
